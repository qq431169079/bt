from BitTorrent import languages
print ' '.join(languages)
